#define UTS_RELEASE "3.19.0-33-generic"
#define UTS_UBUNTU_RELEASE_ABI 33
